package com.example.voicehoroscope;

import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    Button btnSpeak;
    TextView txtResult;

    HashMap<String, String> horoscopeMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSpeak = findViewById(R.id.btnSpeak);
        txtResult = findViewById(R.id.txtResult);

        // Simple horoscopes
        horoscopeMap = new HashMap<>();
        horoscopeMap.put("aries", "Today is a great day for new beginnings.");
        horoscopeMap.put("taurus", "Stay patient, your efforts will soon pay off.");
        horoscopeMap.put("gemini", "Communication is key today.");
        horoscopeMap.put("cancer", "Trust your intuition.");
        horoscopeMap.put("leo", "Take the lead and shine bright.");
        horoscopeMap.put("virgo", "Stay organized and focus on details.");
        horoscopeMap.put("libra", "Seek balance in your relationships.");
        horoscopeMap.put("scorpio", "Embrace transformation.");
        horoscopeMap.put("sagittarius", "Adventure is calling!");
        horoscopeMap.put("capricorn", "Hard work will bring success.");
        horoscopeMap.put("aquarius", "Innovative ideas come to you today.");
        horoscopeMap.put("pisces", "Creativity will guide your day.");

        btnSpeak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startSpeechToText();
            }
        });
    }

    private void startSpeechToText() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say your zodiac sign...");

        try {
            startActivityForResult(intent, 100);
        } catch (Exception e) {
            txtResult.setText("Speech not supported on this device.");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            String spokenText = result.get(0).toLowerCase();

            if (horoscopeMap.containsKey(spokenText)) {
                txtResult.setText("Your horoscope:\n\n" + horoscopeMap.get(spokenText));
            } else {
                txtResult.setText("Couldn't recognize the zodiac sign. Try again.");
            }
        }
    }
}
